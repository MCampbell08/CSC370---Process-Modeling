﻿using System;

namespace ServerUtil
{
    class Program
    {
        static void Main(string[] args)
        {
            new Server().Run();
        }
    }
}
