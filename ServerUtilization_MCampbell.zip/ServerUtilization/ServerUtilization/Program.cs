﻿using System;

namespace ServerUtilization
{
    class Program
    {
        static void Main(string[] args)
        {
            new Server().Run();
        }
    }
}